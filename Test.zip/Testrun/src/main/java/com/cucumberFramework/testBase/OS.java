package com.cucumberFramework.testBase;

public enum OS {	
	WINDOW,
	MAC
}
