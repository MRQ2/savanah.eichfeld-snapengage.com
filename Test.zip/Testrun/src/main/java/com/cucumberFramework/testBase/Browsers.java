package com.cucumberFramework.testBase;

public enum Browsers {	
	CHROME,
	FIREFOX,
}
