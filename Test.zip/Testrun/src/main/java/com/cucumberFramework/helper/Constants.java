package com.cucumberFramework.helper;

public class Constants {

	public class Constant {

		public final static long explicitWait = 60;
		public final static long impliciteWait = 60;

	}
	
}
