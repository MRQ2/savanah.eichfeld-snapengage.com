package com.cucumberFramework.pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cucumberFramework.helper.Constants.Constant;
import com.cucumberFramework.helper.WaitHelper;



public class LoginPage {

	private WebDriver driver;

	@FindBy(xpath = "//input[@id='email']")
	public WebElement Email;

	@FindBy(xpath = "//input[@id='password']")
	WebElement Password;

	@FindBy(xpath = "//input[@title='Click here to sign in to SnapEngage QA']")
	WebElement SignIn;
	
	@FindBy(css = "//div[@class='Navbarcss__NavbarLeftSide-sc-1mp9pg2-1 eYccun']")
	public WebElement Main_navigation;

	WaitHelper waitHelper;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		waitHelper = new WaitHelper(driver);
	}

	public void EmailId(String id) {
		this.Email.sendKeys(id);
	}

	public void enterPassword(String password) {
		this.Password.sendKeys(password);
	}

	public void clickLoginButton() {
		SignIn.click();
	}
	
	public boolean getMain_navigation() {
		WebElement Main_navigation_temp = Main_navigation;
		waitHelper.WaitForElement(Main_navigation_temp, Constant.explicitWait);
		return Main_navigation_temp.isDisplayed();
	}

}
