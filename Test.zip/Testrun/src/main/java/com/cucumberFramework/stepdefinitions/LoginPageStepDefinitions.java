package com.cucumberFramework.stepdefinitions;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import org.testng.Assert;

import com.cucumberFramework.helper.LoggerHelper;
import com.cucumberFramework.helper.WaitHelper;
import com.cucumberFramework.pageObjects.LoginPage;
import com.cucumberFramework.testBase.TestBase;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginPageStepDefinitions extends TestBase {

	Logger log = LoggerHelper.getLogger(LoginPageStepDefinitions.class);
	LoginPage loginPage = new LoginPage(driver);
	WaitHelper waitHelper;
//	public static JavascriptExecutor js = (JavascriptExecutor) driver;

	@Given("^Login page URL \"([^\"]*)\"$")
	public void login_page_URL(String URL) throws Throwable {
		driver.get(URL);
		waitHelper = new WaitHelper(driver);
		waitHelper.WaitForElement(loginPage.Email, 60);

	}

	@Then("^Page should load properly$")
	public void page_should_load_properly() throws Throwable {
		Assert.assertEquals(driver.getCurrentUrl(), "https://snapengage-qa.appspot.com/signin?to=hub");
	}

	@When("^User enters username as \"([^\"]*)\"$")
	public void user_enters_username_as(String id) throws Throwable {
		loginPage.EmailId(id);
	}

	@When("^User enters password as \"([^\"]*)\"$")
	public void user_enters_password_as(String password) throws Throwable {
		loginPage.enterPassword(password);
	}

	@When("^Click on button \"([^\"]*)\"$")
	public void click_on_button(String arg1) throws Throwable {
		loginPage.clickLoginButton();
	}

	@Then("^Agent portal should load properly$")
	public void agent_portal_should_load_properly() throws Throwable {

		if (driver.getTitle() != null) {
			Assert.assertTrue(true);
		}

		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(scrFile, new File("Snapengage.png"));

	}

	@When("^Page loads$")
	public void page_loads() throws Throwable {
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
	}

	@Then("^User takes snapshot of the Homepage$")
	public void user_takes_snapshot_of_the_Homepage() throws Throwable {

		TestBase.driver.quit();
	}

}