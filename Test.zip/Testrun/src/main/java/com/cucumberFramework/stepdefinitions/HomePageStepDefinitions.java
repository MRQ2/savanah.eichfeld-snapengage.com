package com.cucumberFramework.stepdefinitions;



import com.cucumberFramework.helper.LoggerHelper;
import com.cucumberFramework.helper.WaitHelper;
import com.cucumberFramework.pageObjects.LoginPage;
import com.cucumberFramework.testBase.TestBase;
import org.apache.log4j.Logger;

public class HomePageStepDefinitions extends TestBase {
	Logger log = LoggerHelper.getLogger(HomePageStepDefinitions.class);
	LoginPage loginPage = new LoginPage(driver);
	WaitHelper waitHelper;

}